import matplotlib.pyplot as plt
import numpy as np

r = 1.
n = 10
ierr = 0.25
verr = 0.5

i = np.linspace(1, 10, n) + ierr * np.random.randn(n)
v = r * i + verr * np.random.rand(n)


plt.xlabel("Current")
plt.ylabel("Voltage")
plt.grid()
plt.gca().set_facecolor((0.6, 0.6, 0.6, 0.4))
plt.ylim(-10, 50)
plt.scatter(i, v)
plt.savefig("bad.pdf")