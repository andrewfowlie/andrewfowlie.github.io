import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import linregress
np.random.seed(10)

plt.rcParams.update({
    "text.usetex": True,
    "font.family": "serif",
    "font.size": 14,
})

plt.rc('text.latex', preamble=r'\usepackage{fourier}')


r = 1.
n = 10
ierr = 0.25
verr = 0.5

i = np.linspace(1, 10, n) + ierr * np.random.randn(n)
v = r * i + verr * np.random.rand(n)

x = i[:,np.newaxis]
m = np.linalg.lstsq(x, v, rcond=None)[0]

plt.xlabel("Current, $I$ (A)")
plt.ylabel("Voltage, $V$ (V)")

plt.xlim(0, 12)
plt.ylim(0, 12)

plt.gca().minorticks_on()

plt.errorbar(i, v, yerr=verr, xerr=ierr, ls='none', fmt="", color="k", marker='s', capsize=2, markersize=2)

x = np.linspace(0, 12, 1000)
plt.plot(x, m * x, 'r', label='fitted line')



plt.savefig("good.pdf")