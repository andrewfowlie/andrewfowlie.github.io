import numpy as np


np.random.seed(118)


def trial():
    switch_a = np.random.randint(1, 4)
    switch_b = np.random.randint(1, 4)
    same_color = np.random.rand() < 0.25

    if switch_a == switch_b or same_color:
        lights = np.random.choice(["RR", "GG"])
    else:
        lights = np.random.choice(["RG", "GR"])

    return f"{switch_a}{switch_b}{lights}"


def filter(x, ignore_case_a=False, ignore_case_b=False):
    case_a = x[0] == x[1]
    if (case_a and ignore_case_a) or (not case_a and ignore_case_b):
        return f"\\resultignore{{{x}}}"
    return f"\\result{{{x}}}"


def analyse(results):
    n = len(results)

    case_a = [x for x in results if x[0] == x[1]]
    n_a = len(case_a)
    n_b = n - n_a
    case_a_rr = [x for x in case_a if x.endswith("RR")]
    n_a_rr = len(case_a_rr)

    case_b = [x for x in results if x[0] != x[1]]
    case_b_rr_gg = [x for x in case_b if x[-1] == x[-2]]
    n_b_rr_gg = len(case_b_rr_gg)

    print(f"case a = {n_a, n_a / n}")
    print(f"case a rr = {n_a_rr, n_a_rr / n_a}")
    print(f"case b rr or gg = {n_b_rr_gg, n_b_rr_gg / n_b}")


if __name__ == "__main__":
    import sys

    ignore_case_a = int(sys.argv[1])
    ignore_case_b = int(sys.argv[2])

    result = [trial() for _ in range(100)]

    filtered = [filter(r, ignore_case_a, ignore_case_b) for r in result]

    tex_rows = [filtered[i * 10 : i * 10 + 10] for i in range(10)]
    tex_rows = [" & ".join(row) for row in tex_rows if row]
    joined = "\\\\\n".join(tex_rows)

    print(joined)

    result = [trial() for _ in range(10000)]

    analyse(result)
