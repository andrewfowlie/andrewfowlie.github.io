"""
Gravitational field of a point mass.

Produces:
    1. gravitational_field_lines.pdf
    2. gravitational_potential.pdf

Dimensionless units:
    G = M = 1
"""

import numpy as np
import matplotlib.pyplot as plt


# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------

G = 1.0
M = 1.0

# Plot range
XMIN, XMAX = -5, 5
YMIN, YMAX = -5, 5

# Grid
N = 500

# Field-line appearance
STREAMLINE_DENSITY = 1.5

# Potential contours
POTENTIAL_LEVELS = 30


# ---------------------------------------------------------------------
# Grid
# ---------------------------------------------------------------------

x = np.linspace(XMIN, XMAX, N)
y = np.linspace(YMIN, YMAX, N)

X, Y = np.meshgrid(x, y)

R = np.sqrt(X**2 + Y**2)

# ---------------------------------------------------------------------
# Gravitational vector field
# ---------------------------------------------------------------------

gx = -G * M * X / R**3
gy = -G * M * Y / R**3


# ---------------------------------------------------------------------
# Gravitational potential
# ---------------------------------------------------------------------

phi = -G * M / R

# ---------------------------------------------------------------------
# Plot style
# ---------------------------------------------------------------------

plt.rcParams.update(
    {
        "mathtext.fontset": "stix",
        "font.size": 18,
        "font.family": "Platypi",
        "axes.unicode_minus": False,
        "axes.labelsize": 22,
    }
)


# ---------------------------------------------------------------------
# Common plotting style
# ---------------------------------------------------------------------


def setup_axes(ax):
    ax.set_xlim(XMIN, XMAX)
    ax.set_ylim(YMIN, YMAX)

    ax.set_aspect("equal")

    ax.axhline(
        0,
        linewidth=0.5,
        color="0.6",
        zorder=0,
    )

    ax.axvline(
        0,
        linewidth=0.5,
        color="0.6",
        zorder=0,
    )

    ax.set_xlabel("$x$")
    ax.set_ylabel("$y$")

    ax.set_xticks(np.arange(XMIN, XMAX + 1, 1))
    ax.set_yticks(np.arange(YMIN, YMAX + 1, 1))

    ax.grid(
        linewidth=0.35,
        color="0.8",
        linestyle="--",
    )


# ---------------------------------------------------------------------
# 1. Gravitational field lines
# ---------------------------------------------------------------------

fig, ax = plt.subplots(
    figsize=(7, 7),
)

setup_axes(ax)

N_LINES = 32
R_END = 0.08
ARROW_FRACTION = 0.55
LINE_COLOR = "crimson"
LINE_WIDTH = 1.5

# Points on the square boundary

theta = np.linspace(0, 2 * np.pi, N_LINES, endpoint=False)

for t in theta:
    c = np.cos(t)
    s = np.sin(t)

    # Radius at which the ray hits the square boundary
    r_start = min(
        XMAX / abs(c) if c != 0 else np.inf,
        YMAX / abs(s) if s != 0 else np.inf,
    )

    r = np.linspace(r_start, R_END, 200)

    ax.plot(
        r * c,
        r * s,
        color=LINE_COLOR,
        linewidth=LINE_WIDTH,
    )

    # Position of arrow along the line
    r_arrow = 4

    # Arrow points inward, toward the origin
    ax.annotate(
        "",
        xy=(r_arrow * 0.85 * c, r_arrow * 0.85 * s),
        xytext=(r_arrow * 1.15 * c, r_arrow * 1.15 * s),
        arrowprops=dict(
            arrowstyle="->",
            color=LINE_COLOR,
            linewidth=LINE_WIDTH,
            mutation_scale=32,
        ),
    )

# Fix center

ax.plot(0, 0, color=LINE_COLOR, marker="o")

ax.set_title(
    "Gravitational field  — vector field",
    pad=10,
)

fig.savefig(
    "gravitational_field_lines.pdf",
    bbox_inches="tight",
)

plt.close(fig)


# ---------------------------------------------------------------------
# 2. Gravitational potential
# ---------------------------------------------------------------------

fig, ax = plt.subplots(
    figsize=(7, 7),
)

setup_axes(ax)

levels = np.linspace(-5, 0, POTENTIAL_LEVELS)
cmap = plt.get_cmap("gist_heat").copy()
cmap.set_under(cmap(0))

cf = ax.contourf(
    X,
    Y,
    phi,
    alpha=1,
    levels=levels,
    extend="min",
    cmap=cmap,
)


ax.set_title(
    r"Gravitational potential — scalar field",
    pad=10,
)

cax = fig.add_axes([0.93, 0.15, 0.03, 0.70])

cbar = fig.colorbar(cf, cax=cax)
cbar.set_ticks(np.arange(-5, 1))
cbar.set_label(r"$\Phi$")

fig.savefig(
    "gravitational_potential.pdf",
    bbox_inches="tight",
)

plt.close(fig)
