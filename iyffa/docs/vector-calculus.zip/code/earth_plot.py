"""
Three separate weather maps:
    1. Average temperature
    2. Wind quiver plot
    3. Wind streamlines

Based on Fabien Maussion's Climate System lesson:
https://fabienmaussion.info/climate_system/week_04/01_Lesson_Wind-Derivatives-Integrals.html

Input:
    ERA5_LowRes_MonthlyAvg_uvslp.nc

Install:
    pip install numpy xarray matplotlib cartopy netcdf4
"""

from pathlib import Path

import numpy as np
import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature


# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------

WIND_DATA_FILE = Path("ERA5_LowRes_MonthlyAvg_uvslp.nc")
TEMP_DATA_FILE = Path("ERA5_LowRes_Monthly_t2m.nc")

MONTH = 1  # 1 = January, 7 = July

OUTPUT_DIR = Path(".")

# Shared map settings
PROJECTION = ccrs.Robinson()
DATA_CRS = ccrs.PlateCarree()

EXTENT = [-180, 180, -90, 90]

# Shared temperature colour scale
TEMP_LEVELS = np.arange(-40, 41, 5)
TEMP_CMAP = "RdYlBu_r"

# Wind display
QUIVER_SKIP = 9
STREAMLINE_DENSITY = 2.0


# ---------------------------------------------------------------------
# Plot style
# ---------------------------------------------------------------------

plt.rcParams.update(
    {
        "font.size": 22,
        "font.family": "Platypi",
        "font.sans-serif": ["Exo 2"],
        "font.monospace": ["IBM Plex Mono"],
        "axes.unicode_minus": False,
    }
)
# ---------------------------------------------------------------------
# Load data
# ---------------------------------------------------------------------

wind_ds = xr.open_dataset(WIND_DATA_FILE)

print("Available variables:")
print(wind_ds.data_vars)

# Wind components
u = wind_ds["u10"].sel(month=MONTH).load()
v = wind_ds["v10"].sel(month=MONTH).load()

temp_ds = xr.open_dataset(TEMP_DATA_FILE)

print("Available variables:")
print(temp_ds.data_vars)
temperature = temp_ds["t2m"].mean(dim="time")

# Convert Kelvin to Celsius
temperature = temperature - 273.15
temperature.attrs["units"] = "°C"

# Ensure latitude increases from south to north.
# This is important for streamplot and consistent map orientation.
if temperature.latitude[0] > temperature.latitude[-1]:
    temperature = temperature.sortby("latitude")
    u = u.sortby("latitude")
    v = v.sortby("latitude")

# Coordinates and arrays for streamplot
lon = u.longitude.values
lat = u.latitude.values

U = u.values
V = v.values


# ---------------------------------------------------------------------
# Map styling
# ---------------------------------------------------------------------


def setup_map(ax):
    """Apply identical styling to all three maps."""

    ax.set_global()

    ax.add_feature(
        cfeature.OCEAN, facecolor="blue", edgecolor="none", zorder=0, alpha=0.5
    )

    ax.add_feature(
        cfeature.LAND,
        facecolor="green",
        edgecolor="none",
        zorder=0,
        alpha=0.5,
    )
    ax.coastlines(
        color="0.25",
        linewidth=0.6,
    )

    gl = ax.gridlines(
        crs=DATA_CRS,
        draw_labels=True,
        linewidth=0.35,
        color="0.45",
        alpha=0.5,
        linestyle="--",
    )

    gl.top_labels = False
    gl.right_labels = False

    gl.xlabel_style = {"size": 20}
    gl.ylabel_style = {"size": 20}

    return ax


def add_temperature(ax):
    """Draw the shared temperature background."""

    cs = ax.contourf(
        temperature.longitude,
        temperature.latitude,
        temperature,
        levels=TEMP_LEVELS,
        cmap=TEMP_CMAP,
        extend="both",
        transform=DATA_CRS,
    )

    return cs


def add_temperature_colorbar(fig, ax, cs):
    """Add an identical horizontal temperature colourbar."""

    cbar = fig.colorbar(
        cs,
        ax=ax,
        orientation="horizontal",
        pad=0.1,
        fraction=0.05,
        aspect=30,
    )

    cbar.set_label("Temperature (°C)")


# ---------------------------------------------------------------------
# Individual plots
# ---------------------------------------------------------------------


def plot_temperature(ax):
    """Average temperature map."""

    cs = add_temperature(ax)

    return cs


def plot_quiver(ax):
    """Wind arrows over the temperature background."""

    # Subsample arrows for readability
    pu = U[::QUIVER_SKIP, ::QUIVER_SKIP]
    pv = V[::QUIVER_SKIP, ::QUIVER_SKIP]

    plon = lon[::QUIVER_SKIP]
    plat = lat[::QUIVER_SKIP]

    qv = ax.quiver(
        plon,
        plat,
        pu,
        pv,
        transform=DATA_CRS,
        color="black",
        scale=250,
        width=0.002,
        headwidth=3.5,
        headlength=4.5,
        pivot="middle",
    )

    ax.quiverkey(
        qv,
        X=0.88,
        Y=-0.08,
        U=10,
        label="10 ms${}^{-1}$",
        labelpos="E",
        coordinates="axes",
    )


def plot_streamlines(ax):
    """Wind streamlines over the temperature background."""

    ax.streamplot(
        lon,
        lat,
        U,
        V,
        transform=DATA_CRS,
        density=STREAMLINE_DENSITY,
        color="black",
        linewidth=0.7,
        arrowsize=0.8,
    )


def plot_color_streamlines(ax):
    """Wind streamlines over the temperature background."""
    speed = (U**2 + V**2) ** 0.5
    normed = speed / speed.mean()

    ax.streamplot(
        lon,
        lat,
        U,
        V,
        transform=DATA_CRS,
        density=STREAMLINE_DENSITY,
        arrowsize=0.8,
        color=normed,
        linewidth=0.7 * normed**1.5,
        cmap="RdPu",
    )


# ---------------------------------------------------------------------
# Save one map as a separate PDF
# ---------------------------------------------------------------------


def save_map(filename, title, plot_function):
    """Create one map and save it as a PDF."""

    fig, ax = plt.subplots(
        figsize=(12, 6.5),
        subplot_kw={"projection": PROJECTION},
        # constrained_layout=True,
    )

    setup_map(ax)

    cs = plot_function(ax)

    ax.set_title(
        title,
        fontsize=13,
        pad=10,
    )

    if cs is not None:
        add_temperature_colorbar(fig, ax, cs)
        fig.subplots_adjust(bottom=0.175)

    fig.savefig(
        OUTPUT_DIR / filename,
        format="pdf",
    )

    plt.close(fig)

    print(f"Saved {OUTPUT_DIR / filename}")


# ---------------------------------------------------------------------
# Generate the three PDFs
# ---------------------------------------------------------------------

save_map(
    f"temperature_month_{MONTH:02d}.pdf",
    f"Average temperature — month {MONTH}",
    plot_temperature,
)

save_map(
    f"wind_quiver_month_{MONTH:02d}.pdf",
    f"Average wind — quiver, month {MONTH}",
    plot_quiver,
)

save_map(
    f"wind_streamlines_month_{MONTH:02d}.pdf",
    f"Average wind — streamlines, month {MONTH}",
    plot_streamlines,
)

save_map(
    f"wind_color_streamlines_month_{MONTH:02d}.pdf",
    f"Average wind — streamlines, month {MONTH}",
    plot_color_streamlines,
)

# ---------------------------------------------------------------------
# Clean up
# ---------------------------------------------------------------------

temp_ds.close()
wind_ds.close()
