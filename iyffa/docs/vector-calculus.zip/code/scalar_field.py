"""
Gradient of a scalar field
==========================
"""

import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from scipy.integrate import solve_ivp
from scipy.optimize import minimize
from matplotlib.patches import FancyArrowPatch

# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------

XMIN, XMAX = -5, 5
YMIN, YMAX = -5, 5

N = 500

FIELD_LEVELS = 25

# Gradient arrows
ARROW_SPACING = 20
ARROW_SCALE = 2

# Seed points
N_SEEDS = 16
SEED_RADIUS = 0.1
THETA = np.linspace(0, 2 * np.pi, N_SEEDS, endpoint=False)

# Common color style
LINE_COLOR = "Crimson"
LINE_WIDTH = 1.2


# ---------------------------------------------------------------------
# Scalar field
# ---------------------------------------------------------------------


def target(X, Y):
    return (
        2.0 * np.exp(-((X + 2.0) ** 2 + Y**2) / 2.0)
        - 1.5 * np.exp(-((X - 1.5) ** 2 + (Y - 1.5) ** 2) / 1.2)
        - 2.0 * np.exp(-((X - 1.0) ** 2 + (Y + 2.0) ** 2) / 0.8)
    )


def grad_f(x, y):
    e1 = np.exp(-((x + 2.0) ** 2 + y**2) / 2.0)
    e2 = np.exp(-((x - 1.5) ** 2 + (y - 1.5) ** 2) / 1.2)
    e3 = np.exp(-((x - 1.0) ** 2 + (y + 2.0) ** 2) / 0.8)

    fx = -2.0 * (x + 2.0) * e1 + 2.5 * (x - 1.5) * e2 + 5.0 * (x - 1.0) * e3

    fy = -2.0 * y * e1 + 2.5 * (y - 1.5) * e2 + 5.0 * (y + 2.0) * e3

    return np.array([fx, fy])


# ---------------------------------------------------------------------
# Grid
# ---------------------------------------------------------------------

x = np.linspace(XMIN, XMAX, N)
y = np.linspace(YMIN, YMAX, N)
X, Y = np.meshgrid(x, y)
f = target(X, Y)

# ---------------------------------------------------------------------
# Gradient
# ---------------------------------------------------------------------

df_dy, df_dx = np.gradient(f, y, x)
gx = df_dx
gy = df_dy

# ---------------------------------------------------------------------
# Extrema
# ---------------------------------------------------------------------

minima = [
    (-1.0, -2.0),
    (1.5, 1.5),
]

maxima = [(-2.0, 0.0)]

extrema = []

for m in minima:
    result = minimize(lambda xy: target(*xy), m, method="BFGS")
    extrema.append([result.x, True])

for m in maxima:
    result = minimize(lambda xy: -target(*xy), m, method="BFGS")
    extrema.append([result.x, False])


# ---------------------------------------------------------------------
# Plot style
# ---------------------------------------------------------------------

plt.rcParams.update(
    {
        "mathtext.fontset": "stix",
        "font.size": 18,
        "font.family": "Platypi",
        "axes.unicode_minus": False,
        "axes.labelsize": 22,
    }
)

# ---------------------------------------------------------------------
# Common plotting style
# ---------------------------------------------------------------------


def setup_axes(ax):
    ax.set_xlim(XMIN, XMAX)
    ax.set_ylim(YMIN, YMAX)

    ax.set_aspect("equal")

    ax.set_xlabel("$x$")
    ax.set_ylabel("$y$")

    ax.set_xticks(np.arange(XMIN, XMAX + 1, 1))
    ax.set_yticks(np.arange(YMIN, YMAX + 1, 1))


# ---------------------------------------------------------------------
# 1. Gradient field
# ---------------------------------------------------------------------

fig, ax = plt.subplots(
    figsize=(7, 7),
)

setup_axes(ax)

# Scalar field

levels = np.linspace(f.min(), f.max(), FIELD_LEVELS)

ax.contour(
    X,
    Y,
    f,
    levels=levels,
    colors="grey",
    linewidths=1,
    alpha=0.5,
    ls="-",
)


def make_trajectory(xy0, direction=1, t_stop=20, frames=180):
    """Integrate dx/dt = direction * grad f."""

    def rhs(t, xy):
        return direction * grad_f(*xy)

    t_eval = np.linspace(0, t_stop, frames)

    sol = solve_ivp(
        rhs,
        (0, t_stop),
        xy0,
        t_eval=t_eval,
        max_step=0.02,
        rtol=1e-6,
        atol=1e-8,
    )
    return sol


for i, (xy, is_minima) in enumerate(extrema):
    range_ = THETA

    if i == 1:
        range_ += np.pi * 0.25

    if not is_minima:
        range_ = np.linspace(
            np.pi / 2, 3.2 * np.pi / 2, int(N_SEEDS / 2), endpoint=False
        )

    for theta in range_:
        xy0 = xy + SEED_RADIUS * np.array(
            [
                np.cos(theta),
                np.sin(theta),
            ]
        )

        sol = make_trajectory(xy0, direction=1 if is_minima else -1.0)

        ax.plot(
            sol.y[0],
            sol.y[1],
            color=LINE_COLOR,
            linewidth=LINE_WIDTH,
        )

        # Arc length along trajectory
        dx = np.diff(sol.y[0])
        dy = np.diff(sol.y[1])
        ds = np.hypot(dx, dy)
        s = np.concatenate(([0], np.cumsum(ds)))
        total_length = s[-1]

        # Find point at desired fraction of arc length
        arrow_fraction = 0.5
        target_ = arrow_fraction * total_length
        i = np.searchsorted(s, target_)

        # Local tangent: use neighbouring trajectory points
        i0 = max(0, i - 2)
        i1 = min(len(sol.y[0]) - 1, i + 2)

        dx = sol.y[0][i1] - sol.y[0][i0]
        dy = sol.y[1][i1] - sol.y[1][i0]
        length = np.hypot(dx, dy)
        dx /= length
        dy /= length

        # Very short arrow, so essentially only the arrowhead is visible
        eps = 0.03
        arrow_size = 12
        patch = FancyArrowPatch(
            (sol.y[0][i] - eps * dx, sol.y[1][i] - eps * dy),
            (sol.y[0][i] + eps * dx, sol.y[1][i] + eps * dy),
            arrowstyle="-|>" if is_minima else "<|-",
            mutation_scale=22,
            linewidth=0,
            color=LINE_COLOR,
        )

        ax.add_patch(patch)

        ax.plot(*xy, marker="o", ms=10, color=LINE_COLOR)


setup_axes(ax)

ax.set_title(
    r"Gradient vector field $\mathbf{\nabla} f(x, y)$",
    pad=10,
)

fig.savefig(
    "gradient_field.pdf",
    bbox_inches="tight",
)
print("saved gradient field")

plt.close(fig)


# ---------------------------------------------------------------------
# 2. Scalar field
# ---------------------------------------------------------------------

fig, ax = plt.subplots(
    figsize=(7, 7),
)

setup_axes(ax)

cf = ax.contourf(
    X,
    Y,
    f,
    levels=levels,
    cmap="gnuplot2",
    extend="both",
)

# Contours make the geometry of the gradient particularly clear
ax.contour(
    X,
    Y,
    f,
    levels=levels,
    colors="black",
    linewidths=1,
    alpha=0.5,
    ls="-",
)

ax.set_title(
    r"Scalar field  $f(x,y)$",
    pad=10,
)

cax = fig.add_axes([0.93, 0.15, 0.03, 0.70])

cbar = fig.colorbar(cf, cax=cax)
cbar.set_ticks(np.arange(-2, 2.1, 0.5))
cbar.set_label(r"$f(x, y)$")

fig.savefig(
    "scalar_field.pdf",
    bbox_inches="tight",
)

print("saved scalar field")

plt.close(fig)

from matplotlib.animation import FuncAnimation
from matplotlib.animation import FFMpegWriter
import matplotlib

matplotlib.use("Agg")
# ------------------------------------------------------------
# Gradient descent trajectory
# ------------------------------------------------------------

COLOR = "crimson"

time = 10
fps = 50
frames = fps * time


xy0 = [(-1.5, -1.0), (-1.0, 0.8), (-3.0, 0.0)]

sol = [make_trajectory(xy, -1, t_stop=7, frames=frames) for xy in xy0]

fig, ax = plt.subplots(figsize=(8, 8))

cf = ax.contourf(
    X,
    Y,
    f,
    levels=levels,
    cmap="gnuplot2",
    extend="both",
)

setup_axes(ax)

trajectory = [
    ax.plot(
        [],
        [],
        color=COLOR,
        linewidth=1.5,
        alpha=0.7,
    )[0]
    for _ in xy0
]

particle = [
    ax.plot(
        [],
        [],
        "o",
        color=COLOR,
        markersize=8,
    )[0]
    for _ in xy0
]


def update(frame):
    for t, p, s in zip(trajectory, particle, sol):
        t.set_data(
            s.y[0, : frame + 1],
            s.y[1, : frame + 1],
        )

        p.set_data(
            [s.y[0, frame]],
            [s.y[1, frame]],
        )

    return trajectory + particle


anim = FuncAnimation(
    fig,
    update,
    frames=frames,
    interval=frames / time,
    blit=True,
)

writer = FFMpegWriter(
    fps=fps,
    metadata={"title": "Gradient descent"},
    bitrate=4000,
)

anim.save(
    "gradient_descent.mp4",
    writer=writer,
    dpi=150,
)

plt.close(fig)
