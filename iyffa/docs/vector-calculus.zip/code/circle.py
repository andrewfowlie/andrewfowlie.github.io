"""
Vector field
============
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch


# ---------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------

XMIN, XMAX = -5, 5
YMIN, YMAX = -5, 5

RADII = np.arange(0.5, 5.0, 0.5)

# Fixed angular position of arrowheads
ARROW_THETA = [-np.pi / 4, np.pi / 4, 3 * np.pi / 4.0, 5 * np.pi / 4.0]

# Visual style
LINE_COLOR = "Crimson"
LINE_WIDTH = 1.2


# ---------------------------------------------------------------------
# Vector field
# ---------------------------------------------------------------------


def field(x, y):
    return np.array([-y, x])


# ---------------------------------------------------------------------
# Plot style
# ---------------------------------------------------------------------

plt.rcParams.update(
    {
        "mathtext.fontset": "stix",
        "font.size": 18,
        "font.family": "Platypi",
        "axes.unicode_minus": False,
        "axes.labelsize": 22,
    }
)


# ---------------------------------------------------------------------
# Axes
# ---------------------------------------------------------------------


def setup_axes(ax):
    ax.set_xlim(XMIN, XMAX)
    ax.set_ylim(YMIN, YMAX)

    ax.set_aspect("equal")

    ax.set_xlabel("$x$")
    ax.set_ylabel("$y$")

    ax.set_xticks(np.arange(XMIN, XMAX + 1, 1))
    ax.set_yticks(np.arange(YMIN, YMAX + 1, 1))


# ---------------------------------------------------------------------
# Plot
# ---------------------------------------------------------------------

fig, ax = plt.subplots(
    figsize=(7, 7),
)

setup_axes(ax)


# ---------------------------------------------------------------------
# Field lines
# ---------------------------------------------------------------------

theta = np.linspace(
    0,
    2 * np.pi,
    500,
)


for radius in RADII:
    # Circle: x^2 + y^2 = radius^2
    x = radius * np.cos(theta)
    y = radius * np.sin(theta)

    ax.plot(
        x,
        y,
        color=LINE_COLOR,
        linewidth=LINE_WIDTH,
    )

    # -------------------------------------------------------------
    # Arrowhead at a fixed angle
    # -------------------------------------------------------------

    for t in ARROW_THETA:
        x_arrow = radius * np.cos(t)
        y_arrow = radius * np.sin(t)

        # f(x,y) = (-y, x), i.e. counter-clockwise tangent
        dx = -np.sin(t)
        dy = np.cos(t)

        eps = 0.03

        patch = FancyArrowPatch(
            (
                x_arrow - eps * dx,
                y_arrow - eps * dy,
            ),
            (
                x_arrow + eps * dx,
                y_arrow + eps * dy,
            ),
            arrowstyle="-|>",
            mutation_scale=22,
            linewidth=0,
            color=LINE_COLOR,
        )

        ax.add_patch(patch)


# ---------------------------------------------------------------------
# Origin
# ---------------------------------------------------------------------

ax.plot(
    0,
    0,
    marker="o",
    ms=6,
    color=LINE_COLOR,
)


# ---------------------------------------------------------------------
# Title
# ---------------------------------------------------------------------

ax.set_title(
    r"Vector field  $\mathbf{f}(x,y)=-y\,\hat{\mathbf{i}}+x\,\hat{\mathbf{j}}$",
    pad=10,
)


# ---------------------------------------------------------------------
# Save
# ---------------------------------------------------------------------

fig.savefig(
    "circle.pdf",
    bbox_inches="tight",
)

print("saved vector field")

plt.close(fig)
